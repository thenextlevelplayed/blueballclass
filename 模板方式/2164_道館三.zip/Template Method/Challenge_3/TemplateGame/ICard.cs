﻿namespace Template_Method.Challenge_3.TemplateGame;

public interface ICard
{
    object Suit { get; }
    object Rank { get; }
    string ToString();
}