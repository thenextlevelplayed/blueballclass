﻿namespace Template_Method.Challenge_3.TemplateGame;

public enum Showdown_Suit
{
    Club = 0, Diamond = 1, Heart = 2, Spade = 3
}