﻿namespace Template_Method.Challenge_3.TemplateGame;

public class ShowdownGame : Game<Card<Showdown_Rank, Showdown_Suit>>
{
    public ShowdownGame(List<Player<Card<Showdown_Rank, Showdown_Suit>>> players) : base(players)
    {
        _deck.CreateDeckWithCards<Showdown_Rank, Showdown_Suit>();
        _deck.Shuffle();
    }

    protected override Deck<Card<Showdown_Rank, Showdown_Suit>> CreateDeck()
    {
        return new StandardDeck<Card<Showdown_Rank, Showdown_Suit>>();
    }

    public override List<Card<Showdown_Rank, Showdown_Suit>>? Show(Player<Card<Showdown_Rank, Showdown_Suit>> player)
    {
        var cards = player.Decision(null);
        if (cards != null && cards.Count > 0) PlaceCard = cards[0];
        return cards;
    }

    protected override Dictionary<Player<Card<Showdown_Rank, Showdown_Suit>>, Card<Showdown_Rank, Showdown_Suit>>?
        PrintPlayerShowCard()
    {
        var PlayerShowCard =
            new Dictionary<Player<Card<Showdown_Rank, Showdown_Suit>>, Card<Showdown_Rank, Showdown_Suit>>();
        foreach (var player in Players)
        {
            PlayerShowCard.Add(player, Show(player)[0]); //取list中第一章卡
        }

        return PlayerShowCard;
    }
    

    private void SetPoint()
    {
        Dictionary<Player<Card<Showdown_Rank, Showdown_Suit>>, Card<Showdown_Rank, Showdown_Suit>> playersCard =
            PrintPlayerShowCard();
        if (!playersCard.Any())
        {
            return;
        }

        var maxEntry = playersCard
            .OrderByDescending(entry => entry.Value.Rank)
            .ThenByDescending(entry => entry.Value.Suit)
            .First();
        Console.WriteLine($"Player: {maxEntry.Key.Name} has a biggest card => {maxEntry.Value.ToString()}");
        maxEntry.Key.ReceivePoint();
    }

    private void Winner()
    {
        PrintWinner(Players.OrderByDescending(p => p.Point).First());
    }

    //測試用
    public void GameStart()
    {
        //13回合流程
        for (int i = 0; i < 13; i++)
        {
            //玩家抽牌
            foreach (var player in this.Players)
            {
                DrawCard(player);
            }
        }

        for (int i = 0; i < 13; i++)
        {
            //玩家出台
            SetPoint();
        }

        Winner();
    }
}