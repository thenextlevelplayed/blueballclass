﻿namespace Template_Method.Challenge_3.TemplateGame;

public class UNOHumanPlayer : Human<Card<UNO_Rank, UNO_Suit>>
{
    public UNOHumanPlayer(string name, List<Card<UNO_Rank, UNO_Suit>> hand, int point = 0) : base(name, hand,
        point)
    {
    }

    public override List<Card<UNO_Rank, UNO_Suit>> Decision(Card<UNO_Rank, UNO_Suit> card)
    {
        if (this.Hand.Count == 0)
        {
            Console.WriteLine("You don't have any card in hand");
            return null;
        }

        while (true)
        {
            List<Card<UNO_Rank, UNO_Suit>> SuitCards = new List<Card<UNO_Rank, UNO_Suit>>();
            List<Card<UNO_Rank, UNO_Suit>> RankCards = new List<Card<UNO_Rank, UNO_Suit>>();
            for (int i = 0; i < Hand.Count; i++)
            {
                Console.WriteLine($"you have {Hand[i].ToString()}");
                if (Hand[i].Rank == card.Rank)
                {
                    RankCards.Add(Hand[i]);
                }
                else if (Hand[i].Suit == card.Suit)
                {
                    SuitCards.Add(Hand[i]);
                }
            }

            if (RankCards.Count == 0 && SuitCards.Count == 0)
            {
                Console.WriteLine("Oops, you don't have any card pair, you have to draw a card.");
                return null;
            }
            else if (RankCards.Count == 0 && SuitCards.Count > 0)
            {
                Console.WriteLine($"You choose the same suit of card.");
                Console.WriteLine($"Please choose the card you would like to be the top:");
                for (int i = 0; i < SuitCards.Count(); i++)
                {
                    Console.WriteLine($"{SuitCards[i].ToString()} => Index {i}");
                }

                string? indexInput = Console.ReadLine();
                if (!int.TryParse(indexInput, out int index) || index < 0 || index >= SuitCards.Count())
                {
                    Console.WriteLine($"Invalid number! Must be between 0 and {SuitCards.Count() - 1}.");
                    continue;
                }

                for (int i = 0; i < SuitCards.Count(); i++)
                {
                    this.RemoveCard(SuitCards[i]);
                }

                var temp = SuitCards[0];
                SuitCards[0] = SuitCards[index];
                SuitCards[index] = temp;
                return SuitCards;
            }
            else if (RankCards.Count > 0 && SuitCards.Count == 0)
            {
                Console.WriteLine($"You choose the same Rank of card.");
                Console.WriteLine($"Please choose the card you would like to be the head:");

                for (int i = 0; i < RankCards.Count(); i++)
                {
                    Console.WriteLine($"{RankCards[i].ToString()} => Index {i}");
                }

                string? indexInput = Console.ReadLine();
                if (!int.TryParse(indexInput, out int index) || index < 0 || index >= RankCards.Count())
                {
                    Console.WriteLine($"Invalid number! Must be between 0 and {RankCards.Count() - 1}.");
                    continue;
                }

                for (int i = 0; i < SuitCards.Count(); i++)
                {
                    this.RemoveCard(SuitCards[i]);
                }

                var temp = RankCards[0];
                RankCards[0] = RankCards[index];
                RankCards[index] = temp;
                return RankCards;
            }
            else
            {
                // 3種狀況 1 2 同時存在、1存在2不存在、1不存在2存在
                Console.WriteLine("Please choose the card type you would like to play:");
                Console.WriteLine("input number 1 => Choose the same Suit of card");
                Console.WriteLine("input number 2 => Choose the same Rank of card");
                string? typeInput = Console.ReadLine();

                if (string.IsNullOrEmpty(typeInput))
                {
                    Console.WriteLine("Input cannot be null or empty!");
                    continue;
                }

                if (!int.TryParse(typeInput, out int result) || result < 0 || result >= 3)
                {
                    Console.WriteLine($"Invalid number! Must be between 0 or 2.");
                    continue;
                }

                Console.WriteLine($"Please choose the card type you would like to draw:");
                if (result == 1)
                {
                    Console.WriteLine($"You choose the same suit of card.");
                    Console.WriteLine($"Please choose the card you would like to be the top:");
                    for (int i = 0; i < SuitCards.Count(); i++)
                    {
                        Console.WriteLine($"{SuitCards[i].ToString()} => Index {i}");
                    }

                    string? indexInput = Console.ReadLine();
                    if (!int.TryParse(indexInput, out int index) || index < 0 || index >= SuitCards.Count())
                    {
                        Console.WriteLine($"Invalid number! Must be between 1 and {SuitCards.Count() - 1}.");
                        continue;
                    }

                    for (int i = 0; i < SuitCards.Count(); i++)
                    {
                        this.RemoveCard(SuitCards[i]);
                    }

                    var temp = SuitCards[0];
                    SuitCards[0] = SuitCards[index];
                    SuitCards[index] = temp;
                    return SuitCards;
                }
                else if (result == 2)
                {
                    Console.WriteLine($"You choose the same Rank of card.");
                    Console.WriteLine($"Please choose the card you would like to be the head:");

                    for (int i = 0; i < RankCards.Count(); i++)
                    {
                        Console.WriteLine($"{RankCards[i].ToString()} => Index{i}");
                    }

                    string? indexInput = Console.ReadLine();
                    if (!int.TryParse(indexInput, out int index) || index < 0 || index >= RankCards.Count())
                    {
                        Console.WriteLine($"Invalid number! Must be between 1 and {RankCards.Count() - 1}.");
                        continue;
                    }

                    for (int i = 0; i < SuitCards.Count(); i++)
                    {
                        this.RemoveCard(SuitCards[i]);
                    }

                    var temp = RankCards[0];
                    RankCards[0] = RankCards[index];
                    RankCards[index] = temp;
                    return RankCards;
                }
                else
                {
                    continue;
                }
            }
        }
    }
}