﻿namespace Template_Method.Challenge_3.TemplateGame;

public class Card<TSuit, TRank> : ICard where TSuit : Enum where TRank : Enum
{
    // 屬性：使用外部定義的 Suit 和 Rank 列舉
    public TSuit Suit { get; set; }
    public TRank Rank { get; set; }

    // 建構子：初始化一張牌的花色和階級
    public Card(TSuit suit, TRank rank)
    {
        Suit = suit;
        Rank = rank;
    }
    
    // 實現 ICard 的屬性
    object ICard.Suit => Suit; // 將具體類型轉為 object
    object ICard.Rank => Rank;

    // （可選）覆寫 ToString 方法，方便顯示牌的內容
    public override string ToString()
    {
        return $"{Rank} of {Suit}";
    }
}