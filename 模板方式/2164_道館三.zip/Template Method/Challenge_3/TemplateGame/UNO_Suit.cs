﻿namespace Template_Method.Challenge_3.TemplateGame;

public enum UNO_Suit
{
    Blue = 0, Red = 1, Yellow = 2, Green = 3
}