﻿namespace Template_Method.Challenge_3.TemplateGame;

public abstract class Player<TCard>  where TCard : class,ICard
{
    public string Name { get; set; }
    public List<TCard> Hand = new List<TCard>();
    public int Point { get; set; } = 0;
    
    public Player(string name, List<TCard> hand,int  point=0)
    {
        this.Name = name;
        this.Hand = hand;
        this.Point = point;
    }
    
    public void AddCard(TCard card)
    {
        Hand.Add(card);
    }
    
    public void RemoveCard(TCard card)
    {
        Hand.Remove(card);
    }
    
    public void ReceivePoint()
    {
        this.Point++;
    }
    
    public bool DrawCard(TCard card)
    {
        var suit = card.Suit;
        var rank = card.Rank;
        for (int i = 0; i < Hand.Count; i++)
        {
            if (Hand[i].Rank.Equals(rank))
            {
                return false;
            }
            else if (Hand[i].Suit.Equals(suit))
            {
                return false;
            }
        }
        return true;
    }

    protected abstract void NameHimSelf(string? name);

    public abstract List<TCard> Decision(TCard card);
}