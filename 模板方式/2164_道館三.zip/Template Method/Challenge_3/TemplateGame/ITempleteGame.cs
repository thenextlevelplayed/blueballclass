﻿namespace Template_Method.Challenge_3.TemplateGame;

public interface ITempleteGame<TCard> where TCard : class,ICard
{
    TCard PlaceCard { get; set; }
    void DrawCard(Player<TCard> player);
    public List<TCard> Show(Player<TCard> player);
    void PrintWinner(Player<TCard> player);
}