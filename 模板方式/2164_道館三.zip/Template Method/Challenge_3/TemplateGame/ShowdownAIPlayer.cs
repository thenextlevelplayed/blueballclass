﻿namespace Template_Method.Challenge_3.TemplateGame;

public class ShowdownAIPlayer : AI<Card<Showdown_Rank, Showdown_Suit>>
{
    public ShowdownAIPlayer(string name, List<Card<Showdown_Rank, Showdown_Suit>> hand, int point = 0) : base(name,
        hand, point)
    {
    }

    public override List<Card<Showdown_Rank, Showdown_Suit>> Decision(Card<Showdown_Rank, Showdown_Suit> card)
    {
        if (this.Hand.Count == 0)
        {
            Console.WriteLine("You don't have any card in hand");
            return null;
        }

        while (true)
        {
            int random = new Random().Next(0, this.Hand.Count());

            var removeCard = Hand[random];
            this.RemoveCard(removeCard);
            return new List<Card<Showdown_Rank, Showdown_Suit>> { removeCard };
        }
    }
}