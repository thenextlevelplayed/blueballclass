﻿using Template_Method.Challenge_3.TemplateGame;

namespace Template_Method.Challenge_3.TemplateGame;

public abstract class Game<TCard> : ITempleteGame<TCard> where TCard : class, ICard
{
    public TCard PlaceCard { get; set; } // 使用泛型 TCard
    public Deck<TCard> _deck { get; set; }
    public Deck<TCard> _saveDumpCard { get; set; }
    public List<Player<TCard>> Players { get; set; }
    
    protected Game(List<Player<TCard>> players)
    {
        Players = players ?? throw new ArgumentNullException(nameof(players)); // 防範 null
        _deck = CreateDeck();
        _saveDumpCard = CreateDeck();
    }

    protected abstract Deck<TCard> CreateDeck(); // 子類別提供具體牌堆

   public virtual void DrawCard(Player<TCard> player)
    {
        if (ShouldReshuffleDeck())
        {
            ReShuffleDeck();
        }

        player.AddCard(_deck.Draw());
    }

    protected virtual bool ShouldReshuffleDeck()
    {
        return false; // 預設不需要洗牌
    }

    protected void ReShuffleDeck()
    {
        _saveDumpCard.Shuffle();
        _deck = _saveDumpCard;
        _saveDumpCard.Cards.Clear();
        Console.WriteLine("Deck reshuffled from discard pile.");
    }

    public virtual List<TCard> Show(Player<TCard> player)
    {
        var dumpCards = player.Decision(GetCurrentPlaceCard());
        if (dumpCards != null && dumpCards.Count > 0)
        {
            ProcessPlayedCards(dumpCards);
            PlaceCard = dumpCards[dumpCards.Count - 1]; // 更新場上的牌為最後一張
        }

        return dumpCards;
    }

    // 虛擬方法：獲取當前牌，子類別可覆寫
    protected virtual TCard? GetCurrentPlaceCard()
    {
        return PlaceCard; // 預設返回場上的牌
    }

    protected virtual void ProcessPlayedCards(List<TCard> dumpCards)
    {
    }

    //獲取玩家出的牌
    protected virtual Dictionary<Player<TCard>, TCard>? PrintPlayerShowCard()
    {
        return null;
    }

    public void PrintWinner(Player<TCard> player)
    {
        Console.WriteLine($"Winner is {player.Name}");
    }
}