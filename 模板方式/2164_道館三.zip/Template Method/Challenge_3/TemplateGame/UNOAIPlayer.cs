﻿namespace Template_Method.Challenge_3.TemplateGame;

public class UNOAIPlayer : AI<Card<UNO_Rank, UNO_Suit>>
{
    public UNOAIPlayer(string name, List<Card<UNO_Rank, UNO_Suit>> hand, int point = 0) : base(name, hand,
        point)
    {
    }

    public override List<Card<UNO_Rank, UNO_Suit>> Decision(Card<UNO_Rank, UNO_Suit> card)
    {
         if (this.Hand.Count == 0)
        {
            Console.WriteLine("You don't have any card in hand");
            return null;
        }

        while (true)
        {
            List<Card<UNO_Rank, UNO_Suit>> SuitCards = new List<Card<UNO_Rank, UNO_Suit>>();
            List<Card<UNO_Rank, UNO_Suit>> RankCards = new List<Card<UNO_Rank, UNO_Suit>>();
            for (int i = 0; i < Hand.Count; i++)
            {
                if (Hand[i].Rank == card.Rank)
                {
                    RankCards.Add(Hand[i]);
                }
                else if (Hand[i].Suit == card.Suit)
                {
                    SuitCards.Add(Hand[i]);
                }
            }

            if (RankCards.Count == 0 && SuitCards.Count == 0)
            {
                return null;
            }
            else if (RankCards.Count == 0 && SuitCards.Count > 0)
            {
                for (int i = 0; i < SuitCards.Count(); i++)
                {
                    Console.WriteLine($"{SuitCards[i].ToString()} => Index{i}");
                    // Card removeCard = _hand[result];
                    this.RemoveCard(SuitCards[i]);
                }

                int rand = new Random().Next(0, SuitCards.Count());

                var temp = SuitCards[0];
                SuitCards[0] = SuitCards[rand];
                SuitCards[rand] = temp;
                return SuitCards;
            }
            else if (RankCards.Count > 0 && SuitCards.Count == 0)
            {
                Console.WriteLine($"You choose the same Rank of card.");
                Console.WriteLine($"Please choose the card you would like to be the head:");

                for (int i = 0; i < RankCards.Count(); i++)
                {
                    this.RemoveCard(RankCards[i]);
                }

                int rand = new Random().Next(0, RankCards.Count());
                var temp = RankCards[0];
                RankCards[0] = RankCards[rand];
                RankCards[rand] = temp;
                return RankCards;
            }

            Console.WriteLine("Please choose the card type you would like to play:");
            Console.WriteLine("input number 1 => Choose the same Suit of card");
            Console.WriteLine("input number 2 => Choose the same Rank of card");
            int random = new Random().Next(0, 3);

            Console.WriteLine($"Please choose the card type you would like to draw:");
            if (random == 1)
            {
                Console.WriteLine($"You choose the same suit of card.");
                Console.WriteLine($"Please choose the card you would like to be the top:");
                for (int i = 0; i < SuitCards.Count(); i++)
                {
                    Console.WriteLine($"{SuitCards[i].ToString()} => Index{i}");
                    // Card removeCard = _hand[result];
                    this.RemoveCard(SuitCards[i]);
                }

                random = new Random().Next(0, SuitCards.Count());

                var temp = SuitCards[0];
                SuitCards[0] = SuitCards[random];
                SuitCards[random] = temp;
                return SuitCards;
            }
            else if (random == 2)
            {
                Console.WriteLine($"You choose the same Rank of card.");
                Console.WriteLine($"Please choose the card you would like to be the head:");

                for (int i = 0; i < RankCards.Count(); i++)
                {
                    this.RemoveCard(RankCards[i]);
                }

                random = new Random().Next(0, RankCards.Count());
                var temp = RankCards[0];
                RankCards[0] = RankCards[random];
                RankCards[random] = temp;
                return RankCards;
            }
            else
            {
                continue;
            }
        }
    }
}