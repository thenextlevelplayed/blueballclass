﻿namespace Template_Method.Challenge_3.TemplateGame;

public abstract class Deck<TCard> where TCard : class, ICard
{
    private Random random = new Random();
    public List<TCard> _cards;

    public Deck(List<TCard> cards)
    {
        this._cards = cards;
    }

    // 提供屬性來訪問牌組
    public List<TCard> Cards => _cards;

    public void CreateDeckWithCards<TSuit, TRank>() where TSuit : Enum where TRank : Enum
    {
        List<TCard> cards = new List<TCard>();
        foreach (TSuit suit in Enum.GetValues(typeof(TSuit)))
        {
            foreach (TRank rank in Enum.GetValues(typeof(TRank)))
            {
                cards.Add((TCard)(object)new Card<TSuit, TRank>(suit, rank));
            }
        }

        _cards = cards;
    }

    public List<TCard> Shuffle() //Fisher–Yates shuffle
    {
        if (_cards == null)
        {
            throw new Exception("牌卡內必須有牌");
        }

        for (int i = this._cards.Count() - 1; i > 0; i--)
        {
            int randomIndex = random.Next(0, i + 1);
            TCard temp = _cards[i];
            _cards[i] = _cards[randomIndex];
            _cards[randomIndex] = temp;
            Console.WriteLine(_cards[i].ToString());
        }

        return _cards;
    }

    public TCard Draw()
    {
        if (_cards.Count == 0)
        {
            throw new Exception("There is no card inside deck!");
        }

        TCard drawCard = _cards[0];
        this._cards.RemoveAt(0);
        return drawCard;
    }

    public abstract void AddCard(TCard card);

}