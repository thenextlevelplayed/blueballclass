﻿using Template_Method.Challenge_3.TemplateGame;


// UNO 測試
var unoAI1 = new UNOAIPlayer("AI1", new List<Card<UNO_Rank, UNO_Suit>>());
var unoAI2 = new UNOAIPlayer("AI2", new List<Card<UNO_Rank, UNO_Suit>>());
var unoAI3 = new UNOAIPlayer("AI3", new List<Card<UNO_Rank, UNO_Suit>>());
var unoHuman = new UNOHumanPlayer("Bob", new List<Card<UNO_Rank, UNO_Suit>>());
List<Player<Card<UNO_Rank, UNO_Suit>>> UNOPlayers = new List<Player<Card<UNO_Rank, UNO_Suit>>>
{
    unoAI1, unoAI2, unoAI3, unoHuman
};
//game start!
var uno = new UNOGame(UNOPlayers);
uno.GameStart();


Console.WriteLine("\n---\n");

// Showdown 測試
var showdownHand1 = new List<Card<Showdown_Rank, Showdown_Suit>>
    { new Card<Showdown_Rank, Showdown_Suit>(Showdown_Rank.A, Showdown_Suit.Spade) };
var showdownHand2 = new List<Card<Showdown_Rank, Showdown_Suit>>
    { new Card<Showdown_Rank, Showdown_Suit>(Showdown_Rank.K, Showdown_Suit.Heart) };
var showdownAI1 = new ShowdownAIPlayer("AI1", new List<Card<Showdown_Rank, Showdown_Suit>>());
var showdownAI2 = new ShowdownHumanPlayer("Alice", new List<Card<Showdown_Rank, Showdown_Suit>>());
var showdownAI3 = new ShowdownAIPlayer("AI3", new List<Card<Showdown_Rank, Showdown_Suit>>());
var showdownHuman = new ShowdownHumanPlayer("Alice", new List<Card<Showdown_Rank, Showdown_Suit>>());
List<Player<Card<Showdown_Rank, Showdown_Suit>>> ShowdownPlayers = new List<Player<Card<Showdown_Rank, Showdown_Suit>>>
{
    showdownAI1, showdownAI2, showdownAI3, showdownHuman
};
//game start!
var showdown = new ShowdownGame(ShowdownPlayers);
showdown.GameStart();