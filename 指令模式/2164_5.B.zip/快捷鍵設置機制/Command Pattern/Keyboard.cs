﻿namespace 快捷鍵設置機制.Command_Pattern;

public class Keyboard
{
    public Dictionary<char, List<ICommand>> Keys { get; set; }

    public Keyboard()
    {
        Keys = CreateKeys();
    }

    private Dictionary<char, List<ICommand>> CreateKeys()
    {
        var keys = new Dictionary<char, List<ICommand>>();
        for (char c = 'a'; c <= 'z'; c++)
        {
            keys[c] = new List<ICommand>(); 
        }

        return keys;
    }

    public void Reset()
    {
        foreach (var key in Keys.Keys.ToList())
        {
            Keys[key].Clear();
        }
    }
}