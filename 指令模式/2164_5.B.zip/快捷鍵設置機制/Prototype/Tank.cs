﻿namespace 快捷鍵設置機制.Prototype;

public class Tank
{
    public void MoveForward()
    {
        Console.WriteLine("The tank has moved forward.");
    }

    public void MoveBackward()
    {
        Console.WriteLine("The tank has moved backward.");
    }
}