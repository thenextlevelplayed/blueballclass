﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Showdown
{
    public enum Suit
    {
        Club = 0, Diamond = 1, Heart = 2, Spade = 3
    }
}
