﻿namespace diagnosisSystem;

public enum Symptom
{
    Headache,
    Cough,
    Sneeze,
    Snore
}