﻿namespace Big2;

public enum Suit
{
    C = 0, D = 1, H = 2, S = 3
}