﻿namespace 二維地圖冒險遊戲.Enum;

public enum Direction
{
    Up = 0,
    Down = 1,
    Left = 2,
    Right = 3
}