﻿namespace 二維地圖冒險遊戲.Enum;

public enum AttackRangeType
{
    Line = 0,
    FullMapArea = 1,
    OnePointMapArea = 2
}