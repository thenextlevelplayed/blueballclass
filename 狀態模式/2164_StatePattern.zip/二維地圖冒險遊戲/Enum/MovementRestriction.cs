﻿namespace 二維地圖冒險遊戲.Enum;

public enum MovementRestriction
{
    None,
    VerticalOnly,
    HorizontalOnly,
}