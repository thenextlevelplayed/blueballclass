﻿// See https://aka.ms/new-console-template for more information

using 二維地圖冒險遊戲;
Game game = new Game();
game.CreateMapObject();
game.CreateMain();
game.Round();