﻿namespace 二維地圖冒險遊戲;

public interface IMapObject
{
    string DisplaySymbol { get; } // 用於在地圖上顯示的字元

}