﻿using 二維地圖冒險遊戲.Enum;

namespace 二維地圖冒險遊戲.CharacterObject;

public class ActionDetails
{
    public int BaseDamage;
    public AttackRangeType RangeType;
    public List<Direction> AllowDirection;
}