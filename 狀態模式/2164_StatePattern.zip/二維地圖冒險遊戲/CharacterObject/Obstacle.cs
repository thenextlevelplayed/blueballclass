﻿using 二維地圖冒險遊戲.Enum;

namespace 二維地圖冒險遊戲.CharacterObject;

public class Obstacle : Character
{
    public Obstacle(Direction direction) : base(direction)
    {
    }
}